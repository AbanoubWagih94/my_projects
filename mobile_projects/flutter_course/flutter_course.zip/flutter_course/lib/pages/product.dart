import 'package:flutter/material.dart';
import '../ui_elements/title_default.dart';
import '../models/product.dart';
import 'package:map_view/map_view.dart';
class ProdcutPage extends StatelessWidget {
  final Product product;
  ProdcutPage(this.product);

  void _showMap() {
    final List<Marker> markers = <Marker>[
      Marker('position', 'position', product.location.latitude, product.location.longitude)
    ];
    final cameraPosition = CameraPosition(
      Location(product.location.latitude, product.location.longitude),
      14.0
    );
    final mapView = MapView();
    mapView.show(MapOptions(
      initialCameraPosition: cameraPosition,
      mapViewType: MapViewType.normal,
      title: 'Product Location'
    ),
    toolbarActions: [ToolbarAction('Close', 1)]
    );
    mapView.onToolbarAction.listen((int id){
      if(id == 1 ) {
        mapView.dismiss();
      }
    });
    mapView.onMapReady.listen((_){
      mapView.setMarkers(markers);
    });
  }
  Widget _buildAddressPriceRow(double price, String address) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.center,
      children: <Widget>[
        GestureDetector(
          child: Text(address,
              style: TextStyle(fontFamily: '0swald', color: Colors.grey)),
          onTap: _showMap,
        ),
        Container(
          margin: EdgeInsets.symmetric(horizontal: 5.0),
          child: Text(
            '|',
            style: TextStyle(color: Colors.grey),
          ),
        ),
        Text(
          '\$' + price.toString(),
          style: TextStyle(color: Colors.grey),
        )
      ],
    );
  }

  _showWarningDialog(BuildContext context) {
    showDialog(
        context: context,
        builder: (BuildContext context) {
          return AlertDialog(
            title: Text('Are you sure?'),
            content: Text('This action cannot be undone!'),
            actions: <Widget>[
              FlatButton(
                child: Text('DISCARD'),
                onPressed: () => Navigator.pop(context),
              ),
              FlatButton(
                  child: Text('CONTINUE'),
                  onPressed: () {
                    Navigator.pop(context);
                    Navigator.pop(context, true);
                  })
            ],
          );
        });
  }

  @override
  Widget build(BuildContext context) {
    return WillPopScope(
        onWillPop: () {
          Navigator.pop(context, false);
          return Future.value(false);
        },
        child: Scaffold(
            appBar: AppBar(
              title: Text('Product Detail'),
            ),
            body: Column(
              children: <Widget>[
                Container(
                  margin: EdgeInsets.only(top: 10.0),
                  child: FadeInImage(
                    image: NetworkImage(product.image),
                    height: 300.0,
                    fit: BoxFit.cover,
                    placeholder: AssetImage('assets/food.jpg'),
                  ),
                ),
                Container(
                  padding: EdgeInsets.all(10.0),
                  child: TitleDefault(product.title),
                ),
                _buildAddressPriceRow(product.price, product.location.address),
                Container(
                  padding: EdgeInsets.all(10.0),
                  child: RaisedButton(
                    color: Theme.of(context).accentColor,
                    child: Text('DELETE'),
                    onPressed: () {
                      _showWarningDialog(context);
                    },
                  ),
                )
              ],
            )));
  }
}
