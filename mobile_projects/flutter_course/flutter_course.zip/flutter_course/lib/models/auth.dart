enum AuthMode { Signup, Login }
