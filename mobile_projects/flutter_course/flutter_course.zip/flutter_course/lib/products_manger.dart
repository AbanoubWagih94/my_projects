import 'package:flutter/material.dart';


class ProductManger extends StatelessWidget {
  final List<Map<String, dynamic>> products;

  ProductManger(this.products);
  @override
  Widget build(BuildContext context) {
    return Column(children: <Widget>[
      
    ]);
  }
}
